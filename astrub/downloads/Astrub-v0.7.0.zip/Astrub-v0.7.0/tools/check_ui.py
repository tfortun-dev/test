"""Real Chromium checks for the Astrub UI, served by npm run dev.

Run: python tools/check_ui.py
Playwright for Python and a Chromium executable are required.
"""
import json
import os
import shutil
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

OUT = Path(os.getenv('ASTRUB_SCREENSHOTS', str(Path.cwd() / 'ui-checks')))
URL = os.getenv('ASTRUB_TEST_URL', 'http://127.0.0.1:5173/')
VIEWPORTS = [('desktop', 1440, 960), ('mobile', 390, 844), ('landscape', 844, 390)]
if 'ASTRUB_VIEWPORTS' in os.environ:
    selected = {value.strip() for value in os.environ['ASTRUB_VIEWPORTS'].split(',') if value.strip()}
    unknown = selected - {viewport[0] for viewport in VIEWPORTS}
    if not selected or unknown:
        raise ValueError('ASTRUB_VIEWPORTS doit contenir desktop, mobile ou landscape, séparés par des virgules.')
    VIEWPORTS = [viewport for viewport in VIEWPORTS if viewport[0] in selected]


def install_observer(page):
    # Vite timestamps modules during HMR. Reuse the actual loaded module URLs
    # instead of instantiating another Phaser game with a different URL.
    page.evaluate("""async () => {
      const main=document.querySelector('script[src*="/src/main.js"]').src;
      const resource=path=>performance.getEntriesByType('resource').find(e=>new URL(e.name).pathname===path)?.name||path;
      window.__e2e={main:await import(main),state:await import(resource('/src/game/state.js')),iso:await import(resource('/src/game/isometric.js'))};
    }""")


def state(page):
    return page.evaluate("async () => JSON.parse(JSON.stringify((window.__e2e.state).getState()))")


def screenshot(page, name):
    page.screenshot(path=str(OUT / (name + '.png')), animations='disabled')


def active(page, scene):
    page.wait_for_function("async name => (window.__e2e.main).game.scene.isActive(name)", arg=scene)


def scene_value(page, expression):
    return page.evaluate("async () => {const {game}=window.__e2e.main; const scene=game.scene.getScene('VillageScene'); return " + expression + ";}")


def camera(page):
    return scene_value(page, "[scene.cameras.main.scrollX,scene.cameras.main.scrollY,scene.cameras.main.zoom]")


def floor_point(page, building_id):
    return page.evaluate("""async id => {
      const {game}=window.__e2e.main;
      const {getState,BUILDINGS}=window.__e2e.state;
      const {xy}=window.__e2e.iso;
      const b=getState().buildings.find(b=>b.id===id), [w,h]=BUILDINGS[b.type].size;
      const world=xy(b.x+Math.floor(w/2),b.y+Math.floor(h/2));
      const camera=game.scene.getScene('VillageScene').cameras.main;
      const p=camera.matrix.transformPoint(world.x-camera.scrollX,world.y-camera.scrollY);
      return {x:p.x,y:p.y,tag:document.elementFromPoint(p.x,p.y)?.tagName};
    }""", building_id)


def click_building(page, building_id):
    pt = floor_point(page, building_id)
    assert pt['tag'] == 'CANVAS', f"Building floor hidden under UI: {pt}"
    page.mouse.click(pt['x'], pt['y'])
    expect(page.locator('#selection-panel')).to_be_visible()


def open_slot(page, type_name, ignore_id=None):
    return page.evaluate("""async ({type,ignoreId}) => {
      const {game}=window.__e2e.main;
      const {BUILDINGS,canBuild,canMove,getState}=window.__e2e.state;
      const {xy}=window.__e2e.iso;
      const cam=game.scene.getScene('VillageScene').cameras.main;
      const [w,h]=BUILDINGS[type].size;
      const old=ignoreId===null?null:getState().buildings.find(b=>b.id===ignoreId);
      const slots=[];
      for(let x=12;x<29;x++)for(let y=12;y<29;y++){
        if(old&&x===old.x&&y===old.y)continue;
        if(!(ignoreId===null?canBuild(type,x,y):canMove(ignoreId,x,y)))continue;
        const pos=xy(x+Math.floor(w/2),y+Math.floor(h/2));
        const pt=cam.matrix.transformPoint(pos.x-cam.scrollX,pos.y-cam.scrollY);
        if(pt.x<25||pt.y<130||pt.x>innerWidth-25||pt.y>innerHeight-140)continue;
        if(document.elementFromPoint(pt.x,pt.y)?.tagName!=='CANVAS')continue;
        slots.push({x,y,sx:pt.x,sy:pt.y,d:Math.hypot(x-20,y-20)});
      }
      return slots.sort((a,b)=>a.d-b.d)[0];
    }""", {'type':type_name,'ignoreId':ignore_id})


def assert_in_view(page, selector):
    box = page.locator(selector).bounding_box()
    assert box, f'{selector}: no visible box'
    vp = page.viewport_size
    assert box['x'] >= -1 and box['y'] >= -1 and box['x'] + box['width'] <= vp['width'] + 1 and box['y'] + box['height'] <= vp['height'] + 1, f'{selector} leaves viewport: {box}, {vp}'


def show_goals(page):
    if page.locator('#goals-toggle').get_attribute('aria-expanded') == 'false':
        page.locator('#goals-toggle').click()
    expect(page.locator('#goal-action')).to_be_visible()


def run_viewport(browser, label, width, height):
    context = browser.new_context(viewport={'width':width,'height':height}, device_scale_factor=1)
    page = context.new_page()
    errors, failed = [], []
    page.on('pageerror', lambda err: errors.append(str(err)))
    page.on('requestfailed', lambda req: failed.append(req.url))
    page.on('response', lambda res: failed.append(f'{res.status} {res.url}') if res.status >= 400 else None)
    page.goto(URL, wait_until='networkidle')
    install_observer(page)
    active(page, 'VillageScene')
    expect(page.locator('#astrub-startup')).to_be_hidden()
    expect(page.locator('#help-overlay')).to_be_visible()
    assert scene_value(page, 'scene.input.enabled') is False
    screenshot(page, f'after-{label}-help')
    assert_in_view(page, '.help-modal')
    for selector in ['#app','#help-overlay','#game canvas']:
        box=page.locator(selector).bounding_box()
        assert box['x']==0 and box['y']==0 and box['width']==width and box['height']==height, f'Incorrect full-screen bounds: {selector} {box}'
    page.locator('#help-play').click()
    expect(page.locator('#help-overlay')).to_be_hidden()
    assert scene_value(page, 'scene.input.enabled') is True
    screenshot(page, f'after-{label}-village')
    for el in ['#build-toggle','#raid-btn','.resource-stack','.corner-menu']:
        assert_in_view(page, el)
    assert not page.evaluate('document.documentElement.scrollWidth > innerWidth')
    # The first discovery objective opens the correct construction category.
    show_goals(page)
    page.locator('#goal-action').click()
    expect(page.locator('[data-category="army"]')).to_have_attribute('aria-selected','true')
    expect(page.locator('[data-building="barracks"]')).to_be_visible()
    page.locator('#build-close').click()

    # A fresh village cannot launch a raid until a barracks is built.
    page.locator('#raid-btn').click()
    expect(page.locator('#expedition-overlay')).to_be_visible()
    expect(page.locator('#expedition-start')).to_be_disabled()
    expect(page.locator('#expedition-summary')).to_contain_text('caserne')
    assert scene_value(page, 'scene.input.enabled') is False
    before_camera = camera(page)
    page.keyboard.press('d')
    assert camera(page) == before_camera
    page.keyboard.press('Escape')
    expect(page.locator('#expedition-overlay')).to_be_hidden()
    expect(page.locator('#raid-btn')).to_be_focused()

    # Categories show clear costs and never allow an unaffordable choice.
    page.locator('#build-toggle').click()
    page.locator('[data-category="resources"]').click()
    expect(page.locator('#build-filters [role="tab"]')).to_have_count(3)
    expect(page.locator('#build-palette [data-building]')).to_have_count(3)
    screenshot(page, f'after-{label}-build')
    assert_in_view(page, '.build-popout')
    page.locator('[data-category="economy"]').click()
    expect(page.locator('[data-building="warehouse"]')).to_be_visible()
    page.locator('[data-category="army"]').click()
    barracks_card = page.locator('[data-building="barracks"]')
    expect(barracks_card).to_contain_text('360')
    expect(barracks_card).to_contain_text('210')
    original_resources = state(page)['resources']
    page.evaluate("async () => {const s=window.__e2e.state;Object.assign(s.getState().resources,{gold:0,wood:0,stone:0});s.save();}")
    expect(barracks_card).to_be_disabled()
    expect(barracks_card).to_contain_text('Manque')
    page.evaluate("async r => {const s=window.__e2e.state;Object.assign(s.getState().resources,r);s.save();}", original_resources)
    expect(barracks_card).to_be_enabled()
    barracks_card.click()
    expect(page.locator('#placement-status')).to_be_visible()
    if page.locator('#build-toggle').get_attribute('aria-expanded') == 'true':
        page.locator('#build-toggle').click()
    slot = open_slot(page, 'barracks')
    assert slot, 'No accessible valid barracks slot'
    before = state(page)
    page.mouse.move(slot['sx'],slot['sy'])
    page.mouse.click(slot['sx'],slot['sy'])
    page.wait_for_function("async n => (window.__e2e.state).getState().buildings.length===n", arg=len(before['buildings'])+1)
    after = state(page)
    barracks = next(b for b in after['buildings'] if b['type'] == 'barracks')
    assert barracks['x'] == slot['x'] and barracks['y'] == slot['y']
    for key, cost in [('gold',360),('wood',210),('stone',140)]:
        assert after['resources'][key] == before['resources'][key] - cost
    expect(page.locator('#placement-status')).to_be_hidden()

    # Real canvas selection, accessible details, training and free movement.
    click_building(page, barracks['id'])
    expect(page.locator('#selection-title')).to_have_text('Caserne')
    if page.locator('#selection-info-toggle').get_attribute('aria-expanded') == 'false':
        page.locator('#selection-info-toggle').click()
    expect(page.locator('#building-details')).to_be_visible()
    expect(page.locator('#train-controls')).to_be_visible()
    assert_in_view(page, '#selection-panel')
    assert_in_view(page, '#building-details')
    screenshot(page, f'after-{label}-barracks')
    before_train = state(page)
    page.evaluate("async () => {const s=window.__e2e.state;Object.assign(s.getState().resources,{gold:0,wood:0,stone:0});s.save();}")
    expect(page.locator('[data-unit="iop"]')).to_be_disabled()
    expect(page.locator('[data-unit="cra"]')).to_be_disabled()
    expect(page.locator('[data-unit="iop"]')).to_contain_text('Manque')
    page.evaluate("async r => {const s=window.__e2e.state;Object.assign(s.getState().resources,r);s.save();}", before_train['resources'])
    page.locator('[data-unit="iop"]').click()
    after_train = state(page)
    assert len(after_train['queue']) == len(before_train['queue']) + 1
    assert after_train['resources']['gold'] == before_train['resources']['gold'] - 75
    assert after_train['resources']['wood'] == before_train['resources']['wood'] - 12
    page.locator('#selection-info-toggle').click()
    page.locator('#move-btn').click()
    expect(page.locator('#placement-status')).to_be_visible()
    move_slot = open_slot(page, 'barracks', barracks['id'])
    assert move_slot, 'No accessible valid movement slot'
    before_move = state(page)
    page.mouse.move(move_slot['sx'], move_slot['sy'])
    page.mouse.click(move_slot['sx'], move_slot['sy'])
    moved = next(b for b in state(page)['buildings'] if b['id'] == barracks['id'])
    assert (moved['x'],moved['y']) == (move_slot['x'],move_slot['y'])
    assert state(page)['resources'] == before_move['resources']
    expect(page.locator('#placement-status')).to_be_hidden()
    page.locator('#close-selection').click()

    # The next objective selects the principal building and exposes upgrade.
    expect(page.locator('#goal-count')).to_have_text('1/3')
    show_goals(page)
    page.locator('#goal-action').click()
    expect(page.locator('#selection-title')).to_have_text('Maison de guilde')
    expect(page.locator('#building-details')).to_be_visible()
    before_upgrade=state(page)
    page.locator('#upgrade-btn').click()
    expect(page.locator('#upgrade-btn')).to_be_disabled()
    expect(page.locator('#selection-timer')).to_be_visible()
    after_upgrade=state(page)
    assert after_upgrade['resources']['gold']==before_upgrade['resources']['gold']-100
    assert after_upgrade['resources']['wood']==before_upgrade['resources']['wood']-50
    assert after_upgrade['resources']['stone']==before_upgrade['resources']['stone']-30
    # Advance only this upgrade's deadline; no 25-second wall-clock wait.
    page.evaluate("async () => {const s=window.__e2e.state;s.getState().buildings.find(b=>b.type==='townhall').upgradingUntil=Date.now()-1;s.getState().lastTick=Date.now()-600;s.tick();}")
    expect(page.locator('#selection-level')).to_have_text('2')
    expect(page.locator('#goal-count')).to_have_text('2/3')
    page.locator('#close-selection').click()
    show_goals(page)
    page.locator('#goal-action').click()
    expect(page.locator('#expedition-overlay')).to_be_visible()
    page.keyboard.press('Escape')
    expect(page.locator('#raid-btn')).to_be_focused()

    # Keyboard confirmation is a useful alternative to clicking the footprint.
    page.locator('#build-toggle').click()
    page.locator('[data-category="resources"]').click()
    page.locator('[data-building="sawmill"]').click()
    keyboard_slot = open_slot(page, 'sawmill')
    assert keyboard_slot, 'No accessible keyboard placement slot'
    page.mouse.move(keyboard_slot['sx'],keyboard_slot['sy'])
    expect(page.locator('#placement-status')).to_contain_text('Emplacement libre')
    count = len(state(page)['buildings'])
    page.keyboard.press('Enter')
    page.wait_for_function("async n => (window.__e2e.state).getState().buildings.length===n", arg=count+1)
    expect(page.locator('#placement-status')).to_be_hidden()

    # Modal contains keyboard focus, blocks map input, then restores focus.
    page.locator('#raid-btn').click()
    expect(page.locator('#expedition-start')).to_be_enabled()
    assert page.evaluate("document.getElementById('expedition-overlay').contains(document.activeElement)")
    page.keyboard.press('Shift+Tab')
    assert page.evaluate("document.getElementById('expedition-overlay').contains(document.activeElement)")
    page.keyboard.press('Tab')
    assert page.evaluate("document.getElementById('expedition-overlay').contains(document.activeElement)")
    screenshot(page, f'after-{label}-expedition')
    assert_in_view(page, '.expedition-modal')
    page.keyboard.press('Escape')
    expect(page.locator('#raid-btn')).to_be_focused()
    page.locator('#raid-btn').click()
    page.locator('#expedition-start').click()
    active(page, 'BattleScene')
    expect(page.locator('#battle-controls')).to_be_visible()
    expect(page.locator('#raid-btn')).to_be_hidden()
    screenshot(page, f'after-{label}-battle')
    assert_in_view(page, '#battle-controls')
    # A real click deploys one Iop. Leaving consumes only that deployed unit.
    pt = page.evaluate("""async () => {const {game}=window.__e2e.main;const {xy}=window.__e2e.iso;const scene=game.scene.getScene('BattleScene');const world=xy(3,3);const cam=scene.cameras.main;const pt=cam.matrix.transformPoint(world.x-cam.scrollX,world.y-cam.scrollY);return {x:pt.x,y:pt.y,tag:document.elementFromPoint(pt.x,pt.y)?.tagName};}""")
    assert pt['tag'] == 'CANVAS', f'Deployment zone obscured: {pt}'
    before_battle = state(page)
    page.mouse.click(pt['x'],pt['y'])
    page.wait_for_function("async () => (window.__e2e.main).game.scene.getScene('BattleScene').used.iop===1")
    page.locator('#leave-battle').click()
    active(page, 'VillageScene')
    final = state(page)
    assert final['troops']['iop'] == before_battle['troops']['iop'] - 1
    assert final['troops']['cra'] == before_battle['troops']['cra']
    saved = page.evaluate("JSON.parse(localStorage.getItem('astrub_village_local_v1'))")
    assert saved['buildings'] == final['buildings']
    assert saved['troops'] == final['troops']
    if label == 'desktop':
        # One complete raid proves the reward and all discovery objectives.
        page.wait_for_function('() => window.__e2e.state.getState().queue.length===0',timeout=15000)
        page.locator('#raid-btn').click()
        page.locator('#expedition-start').click()
        active(page,'BattleScene')
        before_victory=state(page)
        storage=page.evaluate('window.__e2e.state.cap()')
        pt=page.evaluate("() => {const {game}=window.__e2e.main;const world=window.__e2e.iso.xy(3,3);const cam=game.scene.getScene('BattleScene').cameras.main;const p=cam.matrix.transformPoint(world.x-cam.scrollX,world.y-cam.scrollY);return {x:p.x,y:p.y};}")
        for _ in range(3):
            page.mouse.click(pt['x'],pt['y'])
        page.locator('#troop-palette .build-card').filter(has_text='Crâ').click()
        for _ in range(3):
            page.mouse.click(pt['x'],pt['y'])
        page.wait_for_function('() => window.__e2e.main.game.scene.getScene("BattleScene").used.iop===3 && window.__e2e.main.game.scene.getScene("BattleScene").used.cra===3')
        page.wait_for_function('wins => window.__e2e.state.getState().wins===wins+1',arg=before_victory['wins'],timeout=45000)
        won=state(page)
        for key,reward in [('gold',650),('wood',250),('stone',140)]:
            assert won['resources'][key]==min(storage,before_victory['resources'][key]+reward)
        assert won['troops']['iop']==before_victory['troops']['iop']-3
        assert won['troops']['cra']==before_victory['troops']['cra']-3
        active(page,'VillageScene')
        expect(page.locator('#goal-count')).to_have_text('3/3')
        expect(page.locator('#goal-current')).to_have_text('Votre village prend vie !')
        final=state(page)
        screenshot(page,'after-desktop-victory-return')
    page.reload(wait_until='networkidle')
    install_observer(page)
    active(page, 'VillageScene')
    expect(page.locator('#help-overlay')).to_be_hidden()
    assert state(page)['troops'] == final['troops']
    assert [(b['id'],b['x'],b['y']) for b in state(page)['buildings']] == [(b['id'],b['x'],b['y']) for b in final['buildings']]
    assert not errors, f'Page errors: {errors}'
    assert not failed, f'Failed requests: {failed}'
    result = {'viewport': label, 'width':width,'height':height,'checks':'startup/fullscreen, help, discovery objectives, build costs/availability, canvas building, training, move, upgrade timer, Enter placement, modal focus/escape/input, combat deploy/return, save/reload'+(', victory/reward/troop accounting/3 objectives complete' if label=='desktop' else ''),'pageerrors':errors,'failed_requests':failed}
    context.close()
    return result


if __name__ == '__main__':
    OUT.mkdir(parents=True,exist_ok=True)
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, executable_path=os.getenv('ASTRUB_CHROMIUM') or shutil.which('chromium') or shutil.which('chromium-browser'), args=['--no-sandbox','--disable-dev-shm-usage','--enable-unsafe-swiftshader'])
        results = []
        for label,width,height in VIEWPORTS:
            print(f'Checking {label} {width}x{height}', flush=True)
            try:
                results.append(run_viewport(browser,label,width,height))
            except Exception as error:
                print(str(error),flush=True)
                for context in browser.contexts:
                    for page in context.pages:
                        screenshot(page,f'failure-{label}')
                raise
            (OUT / 'e2e-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
            print(f'PASS {label}',flush=True)
        browser.close()
    (OUT / 'e2e-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    print(json.dumps(results,ensure_ascii=False,indent=2))
